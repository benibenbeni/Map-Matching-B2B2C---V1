
import React, { useEffect, useState, useRef } from 'react';
import { Map, AdvancedMarker, Pin, InfoWindow, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';
import { MAP_STYLE } from '../constants';
import { Candidate } from '../types';
import { Construction, Car, Train, X } from 'lucide-react';

interface MapContainerProps {
  candidates: Candidate[];
  selectedId: number | null;
  onSelect: (id: number | null) => void;
  jobSiteAddress: string;
}

const DEFAULT_CENTER = { lat: 48.8566, lng: 2.3522 };
const DEFAULT_ZOOM = 10;

// --- Internal Directions Component (Optimized & Cleaned) ---
const Directions = ({ 
  origin, 
  destination, 
  travelMode
}: { 
  origin: string | null; 
  destination: { lat: number; lng: number } | null;
  travelMode: 'DRIVING' | 'TRANSIT';
}) => {
  const map = useMap();
  const routesLibrary = useMapsLibrary('routes');
  const directionsServiceRef = useRef<any>(null);
  const directionsRendererRef = useRef<any>(null);

  // Initialize Service and Renderer ONCE
  useEffect(() => {
    if (!routesLibrary || !map) return;
    
    if (!directionsServiceRef.current) {
      directionsServiceRef.current = new (routesLibrary as any).DirectionsService();
    }
    
    if (!directionsRendererRef.current) {
      directionsRendererRef.current = new (routesLibrary as any).DirectionsRenderer({ 
        map,
        suppressMarkers: true,
        preserveViewport: true,
      });
    }

    return () => {
      if (directionsRendererRef.current) {
        directionsRendererRef.current.setMap(null);
        directionsRendererRef.current = null;
      }
    };
  }, [routesLibrary, map]);

  // Update Route and Styling without re-creating the renderer
  useEffect(() => {
    const service = directionsServiceRef.current;
    const renderer = directionsRendererRef.current;

    // IMPORTANT: Clear map if no selection or no site address
    if (!service || !renderer || !origin || !destination) {
      if (renderer) renderer.setDirections({ routes: [] });
      return;
    }

    // Update style based on mode
    renderer.setOptions({
      polylineOptions: {
        strokeColor: travelMode === 'DRIVING' ? '#3b82f6' : '#a855f7',
        strokeWeight: 5,
        strokeOpacity: 0.8,
      }
    });

    service.route({
      origin: origin,
      destination: destination,
      travelMode: travelMode as any,
    }, (response: any, status: string) => {
      if (status === 'OK' && response) {
        renderer.setDirections(response);
      } else {
        renderer.setDirections({ routes: [] });
      }
    });
  }, [origin, destination, travelMode]);

  return null;
};

const MapEffect: React.FC<{ selectedId: number | null; candidates: Candidate[] }> = ({ selectedId, candidates }) => {
  const map = useMap();
  useEffect(() => {
    if (!map || !selectedId) return;
    const candidate = candidates.find(c => c.id === selectedId);
    if (candidate) {
      map.panTo({ lat: candidate.lat, lng: candidate.lng });
    }
  }, [map, selectedId, candidates]);
  return null;
};

const MapContainer: React.FC<MapContainerProps> = ({ candidates, selectedId, onSelect, jobSiteAddress }) => {
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [jobSiteCoords, setJobSiteCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [routePreference, setRoutePreference] = useState<'DRIVING' | 'TRANSIT'>('DRIVING');
  const geocodingLibrary = useMapsLibrary('geocoding');

  // Reset preference when deselected
  useEffect(() => {
    if (selectedId === null) {
        setRoutePreference('DRIVING');
    }
  }, [selectedId]);

  useEffect(() => {
    if (!geocodingLibrary || !jobSiteAddress || jobSiteAddress.trim() === '') {
      setJobSiteCoords(null);
      return;
    }
    const geocoder = new (geocodingLibrary as any).Geocoder();
    geocoder.geocode({ address: jobSiteAddress }, (results: any, status: any) => {
      if (status === 'OK' && results?.[0]) {
        setJobSiteCoords(results[0].geometry.location.toJSON());
      } else {
        setJobSiteCoords(null);
      }
    });
  }, [geocodingLibrary, jobSiteAddress]);

  const getPinColor = (status: string) => {
    switch (status) {
      case 'found': return { background: '#2ecc71', borderColor: '#27ae60', glyphColor: '#ffffff' };
      case 'searching': return { background: '#f39c12', borderColor: '#d35400', glyphColor: '#ffffff' };
      default: return { background: '#e63946', borderColor: '#c0392b', glyphColor: '#ffffff' };
    }
  };

  const selectedCandidate = candidates.find(c => c.id === selectedId);

  return (
    <div className="w-full h-full relative bg-[#0f0f13]">
      <Map
        defaultCenter={DEFAULT_CENTER}
        defaultZoom={DEFAULT_ZOOM}
        mapId="DEMO_MAP_ID" 
        options={{
          styles: MAP_STYLE,
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          backgroundColor: '#0f0f13',
        }}
        className="w-full h-full"
        onClick={() => onSelect(null)} 
      >
        <MapEffect selectedId={selectedId} candidates={candidates} />
        
        {/* Directions logic: only active if candidate AND jobSite address are present */}
        <Directions 
          origin={selectedCandidate && jobSiteAddress?.trim() ? jobSiteAddress : null} 
          destination={selectedCandidate ? { lat: selectedCandidate.lat, lng: selectedCandidate.lng } : null} 
          travelMode={routePreference}
        />

        {jobSiteCoords && (
          <AdvancedMarker position={jobSiteCoords} zIndex={2000}>
            <div className="bg-[#e63946] p-2 rounded-lg border-2 border-white shadow-[0_0_15px_rgba(230,57,70,0.6)] flex items-center justify-center animate-bounce">
               <Construction size={18} className="text-white" />
            </div>
          </AdvancedMarker>
        )}

        {candidates.map((c) => {
          const colors = getPinColor(c.alternanceStatus);
          const isSelected = selectedId === c.id;
          return (
            <AdvancedMarker
              key={c.id}
              position={{ lat: c.lat, lng: c.lng }}
              onClick={(e) => {
                e.domEvent.stopPropagation(); 
                onSelect(c.id);
              }}
              onMouseEnter={() => setHoveredId(c.id)}
              onMouseLeave={() => setHoveredId(null)}
              zIndex={isSelected ? 1000 : 1}
            >
              <div className={`transform transition-transform duration-200 ${isSelected || hoveredId === c.id ? 'scale-125' : 'scale-100'}`}>
                <Pin 
                  background={colors.background} 
                  borderColor={colors.borderColor} 
                  glyphColor={colors.glyphColor}
                  glyph={c.note ? c.note.toString() : ''}
                />
              </div>
            </AdvancedMarker>
          );
        })}

        {selectedCandidate && (
            <InfoWindow
              position={{ lat: selectedCandidate.lat, lng: selectedCandidate.lng }}
              onCloseClick={() => onSelect(null)}
              pixelOffset={[0, -30]}
              headerContent={
                <div className="flex items-center justify-between w-full pr-4">
                  <span className="text-[#0f0f13] font-bold text-sm">
                    {selectedCandidate.prenom} {selectedCandidate.nom}
                  </span>
                </div>
              }
            >
              <div className="text-gray-800 text-xs min-w-[200px] p-1">
                <p className="mb-2 opacity-70">📍 {selectedCandidate.cp} {selectedCandidate.adresse}</p>
                
                {jobSiteAddress && jobSiteAddress.trim() !== '' && (
                  <div className="flex flex-col gap-2 mt-3">
                    <span className="text-[10px] font-bold text-gray-400 uppercase">Voir l'itinéraire :</span>
                    <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
                      <button 
                        onClick={(e) => { e.stopPropagation(); setRoutePreference('DRIVING'); }}
                        className={`flex-1 flex flex-col items-center py-2 rounded-md transition-all ${routePreference === 'DRIVING' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-200'}`}
                      >
                        <Car size={16} />
                        <span className="text-[9px] font-bold mt-1">{selectedCandidate.drivingTime?.text || 'Voiture'}</span>
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setRoutePreference('TRANSIT'); }}
                        className={`flex-1 flex flex-col items-center py-2 rounded-md transition-all ${routePreference === 'TRANSIT' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-200'}`}
                      >
                        <Train size={16} />
                        <span className="text-[9px] font-bold mt-1">{selectedCandidate.transitTime?.text || 'Transport'}</span>
                      </button>
                    </div>
                  </div>
                )}

                <button 
                  onClick={(e) => { e.stopPropagation(); onSelect(null); }}
                  className="w-full mt-4 py-1.5 text-[10px] font-bold text-red-600 border border-red-100 rounded-md hover:bg-red-50 transition-colors flex items-center justify-center gap-1"
                >
                  <X size={12} /> Désélectionner
                </button>
              </div>
            </InfoWindow>
        )}
      </Map>
    </div>
  );
};

export default MapContainer;
