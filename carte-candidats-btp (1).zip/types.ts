
export interface TransitStep {
  name: string;
  color: string;
  textColor: string;
  vehicleType: string;
}

export interface Candidate {
  id: number;
  nom: string;
  prenom: string;
  mail: string;
  tel: string;
  note: number | null;
  cp: string;
  permis: string;
  visa: string;
  dateNaissance: string;
  age: number | null;
  cvPdf: string;
  alternance: string;
  alternanceStatus: 'found' | 'searching' | 'unknown';
  adresse: string;
  lat: number;
  lng: number;
  // Commute fields
  drivingTime?: { text: string; value: number };
  drivingDistance?: string;
  transitTime?: { text: string; value: number };
  transitDistance?: string;
  transitSteps?: TransitStep[];
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export type FilterType = 'all' | 'found' | 'searching';

export interface AppState {
  candidates: Candidate[];
  filteredCandidates: Candidate[];
  loading: boolean;
  error: string | null;
  selectedCandidateId: number | null;
  filter: FilterType;
  searchTerm: string;
  jobSiteAddress: string;
  calculatingCommute: boolean;
}

declare global {
  interface Window {
    google: any;
  }
}
