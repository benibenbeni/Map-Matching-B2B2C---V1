
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { APIProvider, useMapsLibrary } from '@vis.gl/react-google-maps';
import { fetchCandidates } from './services/sheetService';
import { Candidate, FilterType } from './types';
import { MAPS_API_KEY } from './constants';
import { Search, RefreshCw, Navigation, Filter, ChevronDown, ChevronUp, Car, Train, List, Construction, X } from 'lucide-react';
import CandidateList from './components/CandidateList';
import MapContainer from './components/MapContainer';

const DEPTS_IDF = ['75', '77', '78', '91', '92', '93', '94', '95'];
const AGE_RANGES = [
  { id: '-18', label: '-18 ans' },
  { id: '18-21', label: '18-21 ans' },
  { id: '21-26', label: '21-26 ans' },
  { id: '+26', label: '+26 ans' },
];

const AddressInput = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const places = useMapsLibrary('places');

  useEffect(() => {
    if (!places || !inputRef.current) return;

    const autocomplete = new places.Autocomplete(inputRef.current, {
      fields: ['formatted_address'],
      componentRestrictions: { country: 'fr' }
    });

    const listener = autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      if (place.formatted_address) {
        onChange(place.formatted_address);
      }
    });

    return () => {
      if (window.google && window.google.maps) {
        window.google.maps.event.removeListener(listener);
        if(inputRef.current) {
          window.google.maps.event.clearInstanceListeners(inputRef.current);
        }
      }
    }
  }, [places, onChange]);

  return (
    <div className="flex-1 relative">
        <input
            ref={inputRef}
            type="text"
            placeholder="Adresse du chantier..."
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full bg-[#0f0f13] border border-[#2d2d3a] rounded-md px-3 py-1.5 text-xs focus:border-[#e63946] outline-none text-white transition-all placeholder-gray-600 pr-8"
        />
        {value && (
            <button 
                onClick={() => onChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white p-1 hover:bg-[#22222d] rounded transition-colors"
                title="Effacer l'adresse"
            >
                <X size={12} />
            </button>
        )}
    </div>
  );
};

const Dashboard = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [activeStatus, setActiveStatus] = useState<FilterType>('all');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  
  const [showFilters, setShowFilters] = useState(true);
  const [selectedDepts, setSelectedDepts] = useState<string[]>([]);
  const [selectedRatings, setSelectedRatings] = useState<number[]>([]);
  const [selectedAgeRanges, setSelectedAgeRanges] = useState<string[]>([]);
  const [selectedPermis, setSelectedPermis] = useState<string[]>([]);
  const [selectedVisas, setSelectedVisas] = useState<string[]>([]);
  
  const [availablePermis, setAvailablePermis] = useState<string[]>([]);
  const [availableVisas, setAvailableVisas] = useState<string[]>([]);

  const [jobSite, setJobSite] = useState('');
  const [calculating, setCalculating] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'results'>('list');
  const [resultsMode, setResultsMode] = useState<'driving' | 'transit'>('driving');

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchCandidates();
      setCandidates(data);
      
      const uniquePermis = Array.from(new Set(data.map(c => c.permis).filter(Boolean))).sort();
      const uniqueVisas = Array.from(new Set(data.map(c => c.visa).filter(Boolean))).sort();
      setAvailablePermis(uniquePermis);
      setAvailableVisas(uniqueVisas);

    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Quand jobSite est vidé, on réinitialise les infos de trajet
  useEffect(() => {
    if (!jobSite || jobSite.trim() === '') {
        setCandidates(prev => prev.map(c => ({
            ...c,
            drivingTime: undefined,
            drivingDistance: undefined,
            transitTime: undefined,
            transitDistance: undefined
        })));
        if (viewMode === 'results') {
            setViewMode('list');
        }
    }
  }, [jobSite]);

  const filteredCandidates = useMemo(() => {
    let result = candidates.filter(c => {
      const matchesSearch = 
        !searchTerm || 
        c.nom.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.cp.includes(searchTerm);
      
      let matchesStatus = true;
      if (activeStatus === 'found') matchesStatus = c.alternanceStatus === 'found';
      if (activeStatus === 'searching') matchesStatus = c.alternanceStatus === 'searching';

      let matchesDept = true;
      if (selectedDepts.length > 0) matchesDept = selectedDepts.some(d => c.cp.startsWith(d));

      let matchesRating = true;
      if (selectedRatings.length > 0) matchesRating = selectedRatings.includes(c.note || 0);

      let matchesAge = true;
      if (selectedAgeRanges.length > 0 && c.age !== null) {
        matchesAge = selectedAgeRanges.some(range => {
          if (range === '-18') return c.age! < 18;
          if (range === '18-21') return c.age! >= 18 && c.age! <= 21;
          if (range === '21-26') return c.age! > 21 && c.age! <= 26;
          if (range === '+26') return c.age! > 26;
          return false;
        });
      }

      let matchesPermis = true;
      if (selectedPermis.length > 0) matchesPermis = selectedPermis.includes(c.permis);

      let matchesVisa = true;
      if (selectedVisas.length > 0) matchesVisa = selectedVisas.includes(c.visa);

      return matchesSearch && matchesStatus && matchesDept && matchesRating && matchesAge && matchesPermis && matchesVisa;
    });

    result.sort((a, b) => {
        const noteA = a.note || 0;
        const noteB = b.note || 0;
        if (noteA !== noteB) return noteB - noteA;
        return a.nom.localeCompare(b.nom);
    });

    return result;
  }, [candidates, searchTerm, activeStatus, selectedDepts, selectedRatings, selectedAgeRanges, selectedPermis, selectedVisas]);

  // Derived lists for "Results" view
  const topDriving = useMemo(() => {
      return [...candidates]
        .filter(c => c.drivingTime !== undefined)
        .sort((a, b) => (a.drivingTime?.value || Infinity) - (b.drivingTime?.value || Infinity))
        .slice(0, 5);
  }, [candidates]);

  const topTransit = useMemo(() => {
      return [...candidates]
        .filter(c => c.transitTime !== undefined)
        .sort((a, b) => (a.transitTime?.value || Infinity) - (b.transitTime?.value || Infinity))
        .slice(0, 5);
  }, [candidates]);


  const toggleFilter = (list: any[], setList: (l: any[]) => void, item: any) => {
    setList(list.includes(item) ? list.filter(i => i !== item) : [...list, item]);
  };

  const resetAllFilters = () => {
    setSelectedDepts([]);
    setSelectedRatings([]);
    setSelectedAgeRanges([]);
    setSelectedPermis([]);
    setSelectedVisas([]);
    setActiveStatus('all');
    setSearchTerm('');
    setViewMode('list');
    setJobSite('');
  };

  // Auto-calculate for selected candidate if jobsite is present
  useEffect(() => {
    if (!selectedId || !jobSite || jobSite.trim() === '') return;
    const cand = candidates.find(c => c.id === selectedId);
    if (cand && !cand.drivingTime) {
      calculateSingleCommute(selectedId);
    }
  }, [selectedId, jobSite]);

  const calculateSingleCommute = async (id: number) => {
    if (!window.google || !window.google.maps || !jobSite || jobSite.trim() === '') return;
    const target = candidates.find(c => c.id === id);
    if (!target) return;

    const service = new window.google.maps.DistanceMatrixService();
    const dest = { lat: target.lat, lng: target.lng };

    service.getDistanceMatrix({
      origins: [jobSite],
      destinations: [dest],
      travelMode: window.google.maps.TravelMode.DRIVING,
      unitSystem: window.google.maps.UnitSystem.METRIC,
    }, (res: any, status: any) => {
      if (status === 'OK' && res?.rows[0]?.elements[0]?.status === 'OK') {
        const el = res.rows[0].elements[0];
        setCandidates(prev => prev.map(c => c.id === id ? {
          ...c, 
          drivingTime: { text: el.duration.text, value: el.duration.value },
          drivingDistance: el.distance.text
        } : c));
      }
    });

    service.getDistanceMatrix({
      origins: [jobSite],
      destinations: [dest],
      travelMode: window.google.maps.TravelMode.TRANSIT,
      unitSystem: window.google.maps.UnitSystem.METRIC,
    }, (res: any, status: any) => {
      if (status === 'OK' && res?.rows[0]?.elements[0]?.status === 'OK') {
        const el = res.rows[0].elements[0];
        setCandidates(prev => prev.map(c => c.id === id ? {
          ...c, 
          transitTime: { text: el.duration.text, value: el.duration.value },
          transitDistance: el.distance.text
        } : c));
      }
    });
  }

  const stats = useMemo(() => {
    return {
      found: candidates.filter(c => c.alternanceStatus === 'found').length,
      searching: candidates.filter(c => c.alternanceStatus === 'searching').length
    };
  }, [candidates]);

  const calculateCommutes = async () => {
    if (!jobSite || jobSite.trim() === '') return;
    setCalculating(true);
    setViewMode('results'); 

    try {
      if (!window.google || !window.google.maps) throw new Error("Google Maps API not loaded");
      
      const service = new window.google.maps.DistanceMatrixService();
      const targets = filteredCandidates.slice(0, 25);
      if (targets.length === 0) { setCalculating(false); return; }

      const destinations = targets.map(c => ({ lat: c.lat, lng: c.lng }));

      const drivingPromise = new Promise<void>((resolve) => {
          service.getDistanceMatrix({
            origins: [jobSite],
            destinations: destinations,
            travelMode: window.google.maps.TravelMode.DRIVING,
            unitSystem: window.google.maps.UnitSystem.METRIC,
          }, (response: any, status: any) => {
            if (status === 'OK' && response) {
              const results = response.rows[0].elements;
              setCandidates(prev => {
                const next = [...prev];
                targets.forEach((t, index) => {
                   const element = results[index];
                   const candIdx = next.findIndex(c => c.id === t.id);
                   if (candIdx !== -1 && element.status === 'OK') {
                      next[candIdx] = {
                        ...next[candIdx],
                        drivingTime: { text: element.duration.text, value: element.duration.value },
                        drivingDistance: element.distance.text
                      };
                   }
                });
                return next;
              });
            }
            resolve();
          });
      });

      const transitPromise = new Promise<void>((resolve) => {
        service.getDistanceMatrix({
          origins: [jobSite],
          destinations: destinations,
          travelMode: window.google.maps.TravelMode.TRANSIT,
          unitSystem: window.google.maps.UnitSystem.METRIC,
        }, (response: any, status: any) => {
          if (status === 'OK' && response) {
            const results = response.rows[0].elements;
            setCandidates(prev => {
              const next = [...prev];
              targets.forEach((t, index) => {
                 const element = results[index];
                 const candIdx = next.findIndex(c => c.id === t.id);
                 if (candIdx !== -1 && element.status === 'OK') {
                    next[candIdx] = {
                      ...next[candIdx],
                      transitTime: { text: element.duration.text, value: element.duration.value },
                      transitDistance: element.distance.text
                    };
                 }
              });
              return next;
            });
          }
          resolve();
        });
      });

      await Promise.all([drivingPromise, transitPromise]);
      
    } catch (err: any) {
      alert("Erreur: " + err.message);
    } finally {
      setCalculating(false);
    }
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-[#0f0f13] text-[#f1f1f1]">
      <header className="h-[60px] bg-[#1a1a23] border-b border-[#2d2d3a] px-4 flex items-center justify-between shrink-0 z-20 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-[#e63946] to-[#ff6b6b] rounded-lg flex items-center justify-center text-sm shadow-lg shadow-red-900/20 text-white font-bold">
            BTP
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-white">Campus BTP</h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
           <button 
             onClick={resetAllFilters} 
             className="text-[10px] text-gray-400 hover:text-white underline decoration-gray-600 hover:decoration-white transition-all"
           >
             Réinitialiser tout
           </button>
          <button 
            onClick={loadData}
            className="p-1.5 bg-[#22222d] border border-[#2d2d3a] rounded-lg hover:bg-[#343440] text-gray-400 transition-all"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        <aside className="w-[450px] bg-[#1a1a23] border-r border-[#2d2d3a] flex flex-col z-10 shadow-2xl relative flex-shrink-0">
          <div className="flex-none overflow-y-auto custom-scrollbar max-h-[60vh] border-b border-[#2d2d3a]">
             <div className="p-4 space-y-5">
                
                <div className="relative group">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-[#e63946] transition-colors" size={14} />
                  <input
                    type="text"
                    placeholder="Recherche rapide..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-[#0f0f13] border border-[#2d2d3a] rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-[#e63946] focus:ring-1 focus:ring-[#e63946] transition-all"
                  />
                </div>

                <div className="bg-[#22222d] p-3 rounded-lg border border-[#2d2d3a] space-y-2">
                    <div className="flex gap-2">
                        <AddressInput value={jobSite} onChange={setJobSite} />
                        <button 
                            onClick={calculateCommutes}
                            disabled={!jobSite || jobSite.trim() === '' || calculating}
                            className="bg-[#e63946] hover:bg-[#d62839] disabled:bg-gray-700 text-white px-3 py-1.5 rounded-md text-xs font-bold transition-all shadow-lg shadow-red-900/20 flex items-center gap-2 shrink-0"
                        >
                            <Navigation size={12} /> {calculating ? '...' : ''}
                        </button>
                    </div>
                </div>

                {(topDriving.length > 0 || topTransit.length > 0) && (
                    <div className="flex bg-[#0f0f13] p-1 rounded-lg border border-[#2d2d3a]">
                        <button 
                            onClick={() => setViewMode('list')}
                            className={`flex-1 flex items-center justify-center gap-2 py-1.5 rounded text-[10px] font-bold transition-all ${viewMode === 'list' ? 'bg-[#22222d] text-white shadow' : 'text-gray-500 hover:text-gray-300'}`}
                        >
                            <List size={12} /> Filtres
                        </button>
                        <button 
                             onClick={() => setViewMode('results')}
                             className={`flex-1 flex items-center justify-center gap-2 py-1.5 rounded text-[10px] font-bold transition-all ${viewMode === 'results' ? 'bg-[#22222d] text-white shadow' : 'text-gray-500 hover:text-gray-300'}`}
                        >
                            <Navigation size={12} /> Trajets
                        </button>
                    </div>
                )}

                {viewMode === 'list' && (
                    <div className="space-y-4">
                    <div className="flex items-center justify-between cursor-pointer" onClick={() => setShowFilters(!showFilters)}>
                        <h3 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                        <Filter size={12} /> Filtres Avancés
                        </h3>
                        {showFilters ? <ChevronUp size={14} className="text-gray-500"/> : <ChevronDown size={14} className="text-gray-500"/>}
                    </div>

                    {showFilters && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                        
                        <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">STATUT</span>
                            <div className="flex gap-2">
                            {[{id: 'all', label: 'Tous'}, {id: 'found', label: 'Trouvés'}, {id: 'searching', label: 'En recherche'}].map(s => (
                                <button
                                key={s.id}
                                onClick={() => setActiveStatus(s.id as FilterType)}
                                className={`px-3 py-1 rounded-md text-[10px] border transition-all ${activeStatus === s.id ? 'bg-white text-black font-bold' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-400'}`}
                                >
                                {s.label}
                                </button>
                            ))}
                            </div>
                        </div>

                        <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">NOTE /5</span>
                            <div className="flex gap-2">
                            {[5, 4, 3, 2, 1].map(n => (
                                <button
                                key={n}
                                onClick={() => toggleFilter(selectedRatings, setSelectedRatings, n)}
                                className={`w-7 h-7 rounded-full text-[10px] font-bold border transition-all flex items-center justify-center ${selectedRatings.includes(n) ? 'bg-[#f39c12] text-black border-[#f39c12]' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-400'}`}
                                >
                                {n}
                                </button>
                            ))}
                            </div>
                        </div>

                        <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">ÂGE</span>
                            <div className="flex flex-wrap gap-2">
                            {AGE_RANGES.map(r => (
                                <button
                                key={r.id}
                                onClick={() => toggleFilter(selectedAgeRanges, setSelectedAgeRanges, r.id)}
                                className={`px-2 py-1 rounded text-[10px] border transition-all ${selectedAgeRanges.includes(r.id) ? 'bg-[#e63946] text-white border-[#e63946]' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-400'}`}
                                >
                                {r.label}
                                </button>
                            ))}
                            </div>
                        </div>

                        {availablePermis.length > 0 && (
                            <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">PERMIS</span>
                            <div className="flex flex-wrap gap-2">
                                {availablePermis.map(p => (
                                <button
                                    key={p}
                                    onClick={() => toggleFilter(selectedPermis, setSelectedPermis, p)}
                                    className={`px-2 py-1 rounded text-[10px] border transition-all ${selectedPermis.includes(p) ? 'bg-blue-600 text-white border-blue-600' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-400'}`}
                                >
                                    {p}
                                </button>
                                ))}
                            </div>
                            </div>
                        )}

                        {availableVisas.length > 0 && (
                            <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">VISA / STATUT</span>
                            <div className="flex flex-wrap gap-2">
                                {availableVisas.map(v => (
                                <button
                                    key={v}
                                    onClick={() => toggleFilter(selectedVisas, setSelectedVisas, v)}
                                    className={`px-2 py-1 rounded text-[10px] border transition-all ${selectedVisas.includes(v) ? 'bg-purple-600 text-white border-purple-600' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-400'}`}
                                >
                                    {v}
                                </button>
                                ))}
                            </div>
                            </div>
                        )}

                        <div>
                            <span className="text-[10px] text-gray-500 font-semibold mb-2 block">DÉPARTEMENT</span>
                            <div className="flex flex-wrap gap-1.5">
                            {DEPTS_IDF.map(dept => (
                                <button
                                    key={dept}
                                    onClick={() => toggleFilter(selectedDepts, setSelectedDepts, dept)}
                                    className={`w-7 h-7 rounded text-[10px] font-bold flex items-center justify-center border transition-all ${selectedDepts.includes(dept) ? 'bg-gray-200 text-black border-white' : 'bg-[#1a1a23] border-[#2d2d3a] text-gray-500'}`}
                                >
                                {dept}
                                </button>
                            ))}
                            </div>
                        </div>

                        </div>
                    )}
                    </div>
                )}
             </div>
          </div>

          <div className="px-4 py-2 border-b border-[#2d2d3a] bg-[#22222d] text-[10px] text-gray-400 flex justify-between items-center shrink-0">
               {viewMode === 'list' ? (
                   <>
                    <span>{filteredCandidates.length} profils filtrés</span>
                    <div className="flex gap-3">
                        <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500"></span> {stats.found}</span>
                        <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span> {stats.searching}</span>
                    </div>
                   </>
               ) : (
                   <div className="flex items-center gap-2 w-full">
                       <span className="mr-auto">Meilleurs temps (Top 5)</span>
                       <div className="flex bg-[#0f0f13] rounded p-0.5 border border-[#2d2d3a]">
                           <button 
                               onClick={() => setResultsMode('driving')}
                               className={`px-2 py-1 rounded text-[9px] flex items-center gap-1 transition-all ${resultsMode === 'driving' ? 'bg-blue-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}
                           >
                               <Car size={10} /> Voiture
                           </button>
                           <button 
                               onClick={() => setResultsMode('transit')}
                               className={`px-2 py-1 rounded text-[9px] flex items-center gap-1 transition-all ${resultsMode === 'transit' ? 'bg-purple-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}
                           >
                               <Train size={10} /> Transport
                           </button>
                       </div>
                   </div>
               )}
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#1a1a23]">
             {viewMode === 'list' ? (
                <CandidateList 
                    candidates={filteredCandidates} 
                    selectedId={selectedId}
                    onSelect={setSelectedId}
                    mode={jobSite ? 'driving' : 'standard'}
                />
             ) : (
                <div className="p-4">
                    {resultsMode === 'driving' && topDriving.length > 0 && (
                        <div>
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                                <Car size={14} className="text-blue-500" /> Top 5 Voiture
                            </h4>
                            <CandidateList 
                                candidates={topDriving} 
                                selectedId={selectedId}
                                onSelect={setSelectedId}
                                mode="driving"
                            />
                        </div>
                    )}

                    {resultsMode === 'transit' && topTransit.length > 0 && (
                        <div>
                            <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                                <Train size={14} className="text-purple-500" /> Top 5 Transport
                            </h4>
                             <CandidateList 
                                candidates={topTransit} 
                                selectedId={selectedId}
                                onSelect={setSelectedId}
                                mode="transit"
                            />
                        </div>
                    )}

                    {((resultsMode === 'driving' && topDriving.length === 0) || (resultsMode === 'transit' && topTransit.length === 0)) && (
                        <div className="text-center text-gray-500 text-xs py-10">
                            Lancez le calcul d'itinéraire pour voir les résultats.
                        </div>
                    )}
                </div>
             )}
          </div>
        </aside>

        <main className="flex-1 relative bg-[#0f0f13]">
          <MapContainer 
            candidates={filteredCandidates} 
            selectedId={selectedId} 
            onSelect={setSelectedId}
            jobSiteAddress={jobSite}
          />
          
          <div className="absolute bottom-6 left-6 bg-[#1a1a23]/90 backdrop-blur-md border border-[#2d2d3a] p-4 rounded-xl shadow-2xl z-10 max-w-[200px]">
             <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3 tracking-widest">Légende</h4>
             <div className="space-y-3 text-xs">
                <div className="flex items-center gap-2.5">
                   <div className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] shadow-[0_0_8px_rgba(46,204,113,0.5)]"></div>
                   <span className="text-gray-300">Alternance trouvée</span>
                </div>
                <div className="flex items-center gap-2.5">
                   <div className="w-2.5 h-2.5 rounded-full bg-[#f39c12] shadow-[0_0_8px_rgba(243,156,18,0.5)]"></div>
                   <span className="text-gray-300">En recherche</span>
                </div>
                <div className="flex items-center gap-2.5 pt-1 border-t border-[#2d2d3a]">
                   <div className="w-2.5 h-2.5 bg-[#e63946] rounded-sm"></div>
                   <span className="text-gray-300">Chantier</span>
                </div>
             </div>
          </div>
        </main>

      </div>
    </div>
  );
};

const App = () => {
  return (
    <APIProvider apiKey={MAPS_API_KEY} libraries={['places', 'geometry', 'routes']}>
      <Dashboard />
    </APIProvider>
  );
};

export default App;
