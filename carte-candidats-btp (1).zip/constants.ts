
// API Keys
export const SHEETS_API_KEY = 'AIzaSyBUaKGdRT_Ti4JxudF99x9u10MsvLqGOHU';
export const MAPS_API_KEY = 'AIzaSyBQWOduSh7eE9IQJAouzWJ8w8GqgazBgfI';

export const SHEET_ID = '1kdN0hUhHf3lk6-hlS022e0nhJNZsB7RJDQhfrah_hAs';
export const SHEET_NAME = 'Candidats sélectionnés';

// Dark Mode Map Style
export const MAP_STYLE = [
  { "elementType": "geometry", "stylers": [{ "color": "#212121" }] },
  { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] },
  { "elementType": "labels.text.fill", "stylers": [{ "color": "#757575" }] },
  { "elementType": "labels.text.stroke", "stylers": [{ "color": "#212121" }] },
  { "featureType": "administrative", "elementType": "geometry", "stylers": [{ "color": "#757575" }] },
  { "featureType": "administrative.country", "elementType": "labels.text.fill", "stylers": [{ "color": "#9e9e9e" }] },
  { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [{ "color": "#757575" }] },
  { "featureType": "road", "elementType": "geometry.fill", "stylers": [{ "color": "#2c2c2c" }] },
  { "featureType": "road", "elementType": "labels.text.fill", "stylers": [{ "color": "#8a8a8a" }] },
  { "featureType": "road.arterial", "elementType": "geometry", "stylers": [{ "color": "#373737" }] },
  { "featureType": "road.highway", "elementType": "geometry", "stylers": [{ "color": "#3c3c3c" }] },
  { "featureType": "road.highway.controlled_access", "elementType": "geometry", "stylers": [{ "color": "#4e4e4e" }] },
  { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#000000" }] },
  { "featureType": "water", "elementType": "labels.text.fill", "stylers": [{ "color": "#3d3d3d" }] }
];

// Department Center Fallbacks
export const CP_COORDS: Record<string, { lat: number; lng: number }> = {
    '75': { lat: 48.8566, lng: 2.3522 },
    '77': { lat: 48.8396, lng: 2.8016 },
    '78': { lat: 48.8035, lng: 2.1266 },
    '91': { lat: 48.6319, lng: 2.4314 },
    '92': { lat: 48.8924, lng: 2.2357 },
    '93': { lat: 48.9137, lng: 2.4232 },
    '94': { lat: 48.7904, lng: 2.4556 },
    '95': { lat: 49.0347, lng: 2.0786 },
};

// Precise City/Zip Coordinates - RECALIBRATED DATA
export const CP_PRECIS: Record<string, { lat: number; lng: number }> = {
    // --- PARIS ---
    '75001': { lat: 48.8625, lng: 2.3364 },
    '75002': { lat: 48.8682, lng: 2.3428 },
    '75003': { lat: 48.8621, lng: 2.3601 },
    '75004': { lat: 48.8543, lng: 2.3576 },
    '75005': { lat: 48.8445, lng: 2.3490 },
    '75006': { lat: 48.8490, lng: 2.3320 },
    '75007': { lat: 48.8565, lng: 2.3126 },
    '75008': { lat: 48.8725, lng: 2.3126 },
    '75009': { lat: 48.8769, lng: 2.3374 },
    '75010': { lat: 48.8763, lng: 2.3616 },
    '75011': { lat: 48.8590, lng: 2.3780 },
    '75012': { lat: 48.8412, lng: 2.3876 },
    '75013': { lat: 48.8283, lng: 2.3622 },
    '75014': { lat: 48.8295, lng: 2.3271 },
    '75015': { lat: 48.8401, lng: 2.2937 },
    '75016': { lat: 48.8604, lng: 2.2621 },
    '75017': { lat: 48.8835, lng: 2.3067 },
    '75018': { lat: 48.8925, lng: 2.3444 },
    '75019': { lat: 48.8827, lng: 2.3821 },
    '75020': { lat: 48.8631, lng: 2.4001 },

    // --- SEINE-SAINT-DENIS (93) ---
    '93000': { lat: 48.9064, lng: 2.4415 }, // Bobigny
    '93100': { lat: 48.8638, lng: 2.4483 }, // Montreuil
    '93110': { lat: 48.8890, lng: 2.4820 }, // Rosny-sous-Bois
    '93120': { lat: 48.9247, lng: 2.3957 }, // La Courneuve
    '93130': { lat: 48.8893, lng: 2.4570 }, // Noisy-le-Sec
    '93140': { lat: 48.9160, lng: 2.4810 }, // Bondy
    '93150': { lat: 48.9560, lng: 2.4930 }, // Le Blanc-Mesnil
    '93160': { lat: 48.8413, lng: 2.5830 }, // Noisy-le-Grand
    '93170': { lat: 48.8690, lng: 2.4170 }, // Bagnolet
    '93190': { lat: 48.9010, lng: 2.5520 }, // Livry-Gargan
    '93200': { lat: 48.9362, lng: 2.3574 }, // Saint-Denis
    '93210': { lat: 48.9160, lng: 2.3550 }, // La Plaine Saint-Denis
    '93220': { lat: 48.8837, lng: 2.5356 }, // Gagny (RECALIBRÉ)
    '93230': { lat: 48.8840, lng: 2.4340 }, // Romainville
    '93240': { lat: 48.9500, lng: 2.3833 }, // Stains
    '93250': { lat: 48.8860, lng: 2.5080 }, // Villemomble
    '93260': { lat: 48.8780, lng: 2.4080 }, // Les Lilas
    '93270': { lat: 48.9333, lng: 2.4833 }, // Sevran
    '93290': { lat: 48.9500, lng: 2.5000 }, // Tremblay
    '93300': { lat: 48.9147, lng: 2.3834 }, // Aubervilliers
    '93310': { lat: 48.8880, lng: 2.4200 }, // Le Pré-Saint-Gervais
    '93320': { lat: 48.8750, lng: 2.5450 }, // Les Pavillons-sous-Bois
    '93330': { lat: 48.8820, lng: 2.5830 }, // Neuilly-sur-Marne
    '93350': { lat: 48.9450, lng: 2.4410 }, // Le Bourget
    '93360': { lat: 48.8830, lng: 2.5700 }, // Neuilly-Plaisance
    '93370': { lat: 48.9160, lng: 2.5410 }, // Montfermeil
    '93380': { lat: 48.9660, lng: 2.3610 }, // Pierrefitte
    '93390': { lat: 48.9160, lng: 2.5830 }, // Clichy-sous-Bois
    '93400': { lat: 48.9090, lng: 2.3360 }, // Saint-Ouen
    '93410': { lat: 48.9010, lng: 2.5830 }, // Vaujours
    '93420': { lat: 48.9330, lng: 2.5660 }, // Villepinte
    '93430': { lat: 48.9500, lng: 2.4330 }, // Villetaneuse
    '93440': { lat: 48.9330, lng: 2.4170 }, // Dugny
    '93450': { lat: 48.9480, lng: 2.3360 }, // L'Île-Saint-Denis
    '93460': { lat: 48.8410, lng: 2.5830 }, // Gournay-sur-Marne
    '93470': { lat: 48.9010, lng: 2.6160 }, // Coubron
    '93500': { lat: 48.8956, lng: 2.4075 }, // Pantin
    '93600': { lat: 48.9330, lng: 2.5000 }, // Aulnay-sous-Bois
    '93700': { lat: 48.9287, lng: 2.4281 }, // Drancy
    '93800': { lat: 48.9330, lng: 2.3160 }, // Épinay-sur-Seine

    // --- HAUTS-DE-SEINE (92) ---
    '92000': { lat: 48.8924, lng: 2.2043 }, // Nanterre
    '92100': { lat: 48.8350, lng: 2.2400 }, // Boulogne
    '92110': { lat: 48.9050, lng: 2.3080 }, // Clichy
    '92120': { lat: 48.8160, lng: 2.3160 }, // Montrouge
    '92130': { lat: 48.8240, lng: 2.2700 }, // Issy
    '92140': { lat: 48.8010, lng: 2.2610 }, // Clamart
    '92150': { lat: 48.8870, lng: 2.2190 }, // Suresnes
    '92160': { lat: 48.7560, lng: 2.3010 }, // Antony
    '92170': { lat: 48.8160, lng: 2.2850 }, // Vanves
    '92190': { lat: 48.8160, lng: 2.2330 }, // Meudon
    '92200': { lat: 48.8880, lng: 2.2710 }, // Neuilly
    '92210': { lat: 48.8510, lng: 2.2120 }, // Saint-Cloud
    '92220': { lat: 48.8010, lng: 2.3160 }, // Bagneux
    '92230': { lat: 48.9330, lng: 2.3010 }, // Gennevilliers
    '92240': { lat: 48.8110, lng: 2.3160 }, // Malakoff
    '92250': { lat: 48.9110, lng: 2.2510 }, // La Garenne-Colombes
    '92260': { lat: 48.7710, lng: 2.2610 }, // Fontenay-aux-Roses
    '92270': { lat: 48.9210, lng: 2.2160 }, // Bois-Colombes
    '92290': { lat: 48.7810, lng: 2.2610 }, // Châtenay-Malabry
    '92300': { lat: 48.8950, lng: 2.2880 }, // Levallois-Perret
    '92310': { lat: 48.8260, lng: 2.2160 }, // Sèvres
    '92320': { lat: 48.8060, lng: 2.2850 }, // Châtillon
    '92330': { lat: 48.7910, lng: 2.2510 }, // Sceaux
    '92340': { lat: 48.7760, lng: 2.2850 }, // Bourg-la-Reine
    '92350': { lat: 48.7810, lng: 2.2330 }, // Le Plessis-Robinson
    '92360': { lat: 48.7710, lng: 2.2330 }, // Meudon-la-Forêt
    '92370': { lat: 48.8310, lng: 2.1850 }, // Chaville
    '92380': { lat: 48.8160, lng: 2.1850 }, // Garches
    '92390': { lat: 48.9310, lng: 2.3160 }, // Villeneuve-la-Garenne
    '92400': { lat: 48.8970, lng: 2.2510 }, // Courbevoie
    '92500': { lat: 48.8769, lng: 2.1894 }, // Rueil-Malmaison
    '92600': { lat: 48.9110, lng: 2.2850 }, // Asnières
    '92700': { lat: 48.9210, lng: 2.2510 }, // Colombes
    '92800': { lat: 48.8810, lng: 2.2350 }, // Puteaux

    // --- VAL-DE-MARNE (94) ---
    '94000': { lat: 48.7904, lng: 2.4556 }, // Créteil
    '94100': { lat: 48.8050, lng: 2.4850 }, // Saint-Maur
    '94110': { lat: 48.8010, lng: 2.3160 }, // Arcueil
    '94120': { lat: 48.8410, lng: 2.4830 }, // Fontenay-sous-Bois
    '94130': { lat: 48.8350, lng: 2.5010 }, // Nogent-sur-Marne
    '94140': { lat: 48.8054, lng: 2.4203 }, // Alfortville
    '94150': { lat: 48.7610, lng: 2.4160 }, // Rungis
    '94160': { lat: 48.8450, lng: 2.4350 }, // Saint-Mandé
    '94170': { lat: 48.8110, lng: 2.5010 }, // Le Perreux
    '94190': { lat: 48.7360, lng: 2.4510 }, // Villeneuve-Saint-Georges
    '94200': { lat: 48.8110, lng: 2.3850 }, // Ivry-sur-Seine
    '94220': { lat: 48.8160, lng: 2.4160 }, // Charenton
    '94230': { lat: 48.8010, lng: 2.3360 }, // Cachan
    '94240': { lat: 48.7810, lng: 2.3160 }, // L'Haÿ-les-Roses
    '94250': { lat: 48.8110, lng: 2.3510 }, // Gentilly
    '94260': { lat: 48.7919, lng: 2.3361 }, // Fresnes
    '94270': { lat: 48.8110, lng: 2.3510 }, // Le Kremlin-Bicêtre
    '94290': { lat: 48.7510, lng: 2.4330 }, // Villeneuve-le-Roi
    '94300': { lat: 48.8460, lng: 2.4410 }, // Vincennes
    '94310': { lat: 48.7610, lng: 2.4330 }, // Orly
    '94320': { lat: 48.7810, lng: 2.4160 }, // Thiais
    '94340': { lat: 48.8160, lng: 2.5330 }, // Joinville
    '94350': { lat: 48.8330, lng: 2.5510 }, // Villiers-sur-Marne
    '94360': { lat: 48.8330, lng: 2.5660 }, // Bry-sur-Marne
    '94370': { lat: 48.8010, lng: 2.5510 }, // Sucy-en-Brie
    '94380': { lat: 48.7910, lng: 2.5330 }, // Bonneuil
    '94400': { lat: 48.7875, lng: 2.3929 }, // Vitry-sur-Seine
    '94410': { lat: 48.8160, lng: 2.4330 }, // Saint-Maurice
    '94420': { lat: 48.7710, lng: 2.5510 }, // Le Plessis-Trévise
    '94430': { lat: 48.8010, lng: 2.5660 }, // Chennevières
    '94440': { lat: 48.7160, lng: 2.5160 }, // Santeny
    '94450': { lat: 48.7510, lng: 2.4510 }, // Limeil-Brévannes
    '94460': { lat: 48.7698, lng: 2.5097 }, // Valenton
    '94470': { lat: 48.7330, lng: 2.5160 }, // Boissy-Saint-Léger
    '94480': { lat: 48.7160, lng: 2.4830 }, // Ablon
    '94490': { lat: 48.7810, lng: 2.5510 }, // Ormesson
    '94500': { lat: 48.8110, lng: 2.5160 }, // Champigny-sur-Marne
    '94510': { lat: 48.7330, lng: 2.5510 }, // Le Queue-en-Brie
    '94520': { lat: 48.7010, lng: 2.5330 }, // Mandres-les-Roses
    '94550': { lat: 48.7510, lng: 2.3510 }, // Chevilly-Larue
    '94600': { lat: 48.7710, lng: 2.4510 }, // Choisy-le-Roi
    '94700': { lat: 48.8160, lng: 2.4510 }, // Maisons-Alfort
    '94800': { lat: 48.7810, lng: 2.3510 }, // Villejuif
    '94880': { lat: 48.8010, lng: 2.5830 }, // La Varenne Saint-Hilaire

    // --- VAL-D'OISE (95) ---
    '95000': { lat: 49.0333, lng: 2.0667 }, // Cergy-Pontoise
    '95100': { lat: 48.9472, lng: 2.2467 }, // Argenteuil
    '95110': { lat: 48.9550, lng: 2.2460 }, // Sannois
    '95120': { lat: 48.9710, lng: 2.2330 }, // Ermont
    '95130': { lat: 48.9810, lng: 2.2160 }, // Franconville
    '95140': { lat: 48.9728, lng: 2.4014 }, // Garges-lès-Gonesse
    '95150': { lat: 49.0310, lng: 2.1610 }, // Taverny
    '95160': { lat: 48.9910, lng: 2.2830 }, // Montmorency
    '95170': { lat: 48.9810, lng: 2.3010 }, // Deuil-la-Barre
    '95190': { lat: 49.0110, lng: 2.5010 }, // Goussainville
    '95200': { lat: 48.9961, lng: 2.3808 }, // Sarcelles
    '95210': { lat: 48.9810, lng: 2.3510 }, // Saint-Gratien
    '95220': { lat: 49.0010, lng: 2.1660 }, // Herblay
    '95230': { lat: 48.9810, lng: 2.3330 }, // Soisy-sous-Montmorency
    '95240': { lat: 48.9660, lng: 2.1830 }, // Cormeilles-en-Parisis
    '95300': { lat: 49.0510, lng: 2.1010 }, // Pontoise
    '95370': { lat: 49.0147, lng: 2.5267 }, // Louvres
    '95400': { lat: 49.0094, lng: 2.3936 }, // Villiers-le-Bel
    '95460': { lat: 49.0267, lng: 2.0631 }, // Ézanville
    '95500': { lat: 48.9860, lng: 2.4510 }, // Gonesse
    '95600': { lat: 48.9910, lng: 2.2510 }, // Eaubonne
    '95870': { lat: 48.9330, lng: 2.2160 }, // Bezons
    '95880': { lat: 48.9710, lng: 2.3160 }, // Enghien-les-Bains

    // --- YVELINES (78) ---
    '78000': { lat: 48.8035, lng: 2.1266 }, // Versailles
    '78100': { lat: 48.8910, lng: 2.1010 }, // St-Germain-en-Laye
    '78120': { lat: 48.8439, lng: 2.0900 }, // Rambouillet
    '78130': { lat: 48.9310, lng: 2.0330 }, // Les Mureaux
    '78140': { lat: 48.7810, lng: 2.2160 }, // Vélizy
    '78150': { lat: 48.8260, lng: 2.1160 }, // Le Chesnay
    '78170': { lat: 48.8510, lng: 2.1330 }, // La Celle-Saint-Cloud
    '78180': { lat: 48.7760, lng: 2.0410 }, // Montigny-le-Bretonneux
    '78190': { lat: 48.7510, lng: 1.9830 }, // Trappes
    '78200': { lat: 48.9910, lng: 1.7160 }, // Mantes-la-Jolie
    '78210': { lat: 48.8010, lng: 2.0160 }, // Saint-Cyr-l'École
    '78220': { lat: 48.8010, lng: 2.1660 }, // Viroflay
    '78260': { lat: 48.9610, lng: 2.1510 }, // Achères
    '78300': { lat: 48.9310, lng: 2.0410 }, // Poissy
    '78340': { lat: 48.8210, lng: 1.9830 }, // Les Clayes-sous-Bois
    '78360': { lat: 48.9160, lng: 2.1660 }, // Montesson
    '78370': { lat: 48.8210, lng: 2.0830 }, // Plaisir
    '78390': { lat: 48.8160, lng: 2.0160 }, // Bois-d'Arcy
    '78400': { lat: 48.9110, lng: 2.1660 }, // Chatou
    '78420': { lat: 48.9410, lng: 2.1830 }, // Carrières-sur-Seine
    '78500': { lat: 48.9397, lng: 2.1581 }, // Sartrouville
    '78600': { lat: 48.9360, lng: 2.1160 }, // Maisons-Laffitte
    '78700': { lat: 48.9910, lng: 1.6660 }, // Conflans
    '78800': { lat: 48.9160, lng: 2.1830 }, // Houilles

    // --- ESSONNE (91) ---
    '91000': { lat: 48.6319, lng: 2.4314 }, // Évry
    '91100': { lat: 48.6160, lng: 2.4830 }, // Corbeil-Essonnes
    '91120': { lat: 48.7210, lng: 2.2660 }, // Palaiseau
    '91130': { lat: 48.7010, lng: 2.4160 }, // Ris-Orangis
    '91140': { lat: 48.6860, lng: 2.2160 }, // Villebon
    '91160': { lat: 48.7110, lng: 2.2830 }, // Longjumeau
    '91170': { lat: 48.6310, lng: 2.3510 }, // Viry-Châtillon
    '91200': { lat: 48.7010, lng: 2.3510 }, // Athis-Mons
    '91210': { lat: 48.6410, lng: 2.4510 }, // Draveil
    '91260': { lat: 48.7031, lng: 2.4897 }, // Juvisy
    '91270': { lat: 48.6710, lng: 2.4510 }, // Vigneux
    '91300': { lat: 48.6810, lng: 2.2830 }, // Massy
    '91330': { lat: 48.6967, lng: 2.1633 }, // Yerres
    '91350': { lat: 48.6510, lng: 2.3950 }, // Grigny
    '91390': { lat: 48.6010, lng: 2.2830 }, // Morsang
    '91400': { lat: 48.7010, lng: 2.1660 }, // Orsay
    '91420': { lat: 48.6660, lng: 2.2160 }, // Morangis
    '91430': { lat: 48.7330, lng: 2.2160 }, // Igny
    '91550': { lat: 48.7330, lng: 2.4330 }, // Paray-Vieille-Poste
    '91600': { lat: 48.6810, lng: 2.3510 }, // Savigny-sur-Orge
    '91620': { lat: 48.5817, lng: 2.4578 }, // La Ville-du-Bois
    '91700': { lat: 48.6410, lng: 2.3160 }, // Sainte-Geneviève
    '91800': { lat: 48.6910, lng: 2.5010 }, // Brunoy
    '91910': { lat: 48.6110, lng: 2.4160 }, // Saint-Germain-lès-Arpajon
    '91940': { lat: 48.6347, lng: 2.3756 }, // Les Ulis

    // --- SEINE-ET-MARNE (77) ---
    '77000': { lat: 48.5410, lng: 2.6510 }, // Melun
    '77100': { lat: 48.9560, lng: 2.8910 }, // Meaux
    '77127': { lat: 48.7360, lng: 2.5660 }, // Lieusaint
    '77150': { lat: 48.8160, lng: 2.6160 }, // Lésigny
    '77170': { lat: 48.7510, lng: 2.6330 }, // Brie-Comte-Robert
    '77176': { lat: 48.6510, lng: 2.5660 }, // Savigny-le-Temple
    '77181': { lat: 48.8810, lng: 2.6830 }, // Courtry
    '77184': { lat: 48.8310, lng: 2.6010 }, // Émerainville
    '77185': { lat: 48.8510, lng: 2.6330 }, // Lognes
    '77186': { lat: 48.8010, lng: 2.6660 }, // Noisiel
    '77190': { lat: 48.5160, lng: 2.6160 }, // Dammarie-les-Lys
    '77200': { lat: 48.8410, lng: 2.6510 }, // Torcy
    '77270': { lat: 48.8910, lng: 2.6510 }, // Villeparisis
    '77340': { lat: 48.8160, lng: 2.6160 }, // Pontault-Combault
    '77400': { lat: 48.8810, lng: 2.7010 }, // Lagny
    '77420': { lat: 48.8510, lng: 2.5830 }, // Champs-sur-Marne
    '77500': { lat: 48.8810, lng: 2.6010 }, // Chelles
    '77600': { lat: 48.8510, lng: 2.7160 }, // Bussy-Saint-Georges
    '77680': { lat: 48.7810, lng: 2.6510 }, // Roissy-en-Brie
    '77700': { lat: 48.8710, lng: 2.7830 }, // Chessy / Serris
};
